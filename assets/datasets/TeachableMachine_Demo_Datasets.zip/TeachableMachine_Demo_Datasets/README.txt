Teachable Machine demo datasets (no camera/mic)

How to use (Image Project):
1) Open Teachable Machine → Image Project
2) For each class, click Upload → select the images in TRAIN/<class folder>
3) Train Model
4) Test by uploading images from TEST/<class folder>

Folders:
- Lesson1_Shapes_Circle_vs_Triangle: clean 2-class dataset
- Lesson2_Bias_BackgroundTrap: training has background bias; TEST swaps backgrounds
- Lesson4_Shapes_3Class: circle/triangle/square dataset

Tip: Use TEST images only for testing (do not upload them into training).
